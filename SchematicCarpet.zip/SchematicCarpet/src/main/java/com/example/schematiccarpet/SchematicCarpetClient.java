package com.example.schematiccarpet;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.ButtonBlock;
import net.minecraft.block.CarpetBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.FluidBlock;
import net.minecraft.block.LeverBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.Iterator;

/**
 * Schematic Carpet (client side, Litematica helper for mapart).
 *
 * Source reconstructed from the compiled 1.0.3 jar, plus the 1.0.4 change:
 * the auto-grab from the inventory now also runs when the main hand is EMPTY
 * (for example when the last carpet of a color was just used up while right-click is held).
 */
public class SchematicCarpetClient implements ClientModInitializer {

	private static final int PLACE_INTERVAL_TICKS = 2;
	private static final int POSITION_CACHE_TICKS = 40;
	private static final int POSITION_CACHE_MAX = 16;
	private static final int SWAP_SETTLE_TICKS = 0;

	private static long lastMessageMs = 0L;
	private static long tickCounter = 0L;
	private static long lastPlaceTick = -1000L;
	private static long lastSwapTick = -1000L;
	private static long lastMainSwapNanos = 0L;
	private static int lastTargetSlot = 0;
	private static boolean handling = false;

	private static final ArrayDeque<Cached> placedCache = new ArrayDeque<>();

	private static Method schematicWorldGetter;
	private static boolean schematicLookupFailed = false;

	private record Cached(BlockPos pos, long expiresAtTick) {
	}

	@Override
	public void onInitializeClient() {
		UseBlockCallback.EVENT.register(SchematicCarpetClient::onUse);
		ClientTickEvents.START_CLIENT_TICK.register(SchematicCarpetClient::onTick);
	}

	private static void onTick(MinecraftClient client) {
		tickCounter++;

		ClientPlayerEntity player = client.player;
		ClientPlayerInteractionManager interaction = client.interactionManager;
		if (player == null || interaction == null || client.world == null || client.currentScreen != null) {
			return;
		}

		if (!client.options.useKey.isPressed() || player.isSpectator() || player.isUsingItem()) {
			return;
		}
		if (tickCounter - lastPlaceTick < PLACE_INTERVAL_TICKS) {
			return;
		}
		if (tickCounter - lastSwapTick < SWAP_SETTLE_TICKS) {
			return;
		}

		ItemStack held = player.getMainHandStack();
		boolean holdingCarpet = isCarpet(held);
		// 1.0.4: an EMPTY hand is allowed too, so that when a color runs out mid-hold
		// the needed color is pulled from the hotbar / inventory automatically.
		// Any other non-carpet item in hand is still left alone.
		if (!holdingCarpet && !held.isEmpty()) {
			return;
		}

		World schematic = getSchematicWorld();
		if (schematic == null) {
			return;
		}

		HitResult hit = player.raycast(player.getBlockInteractionRange(), 1.0F, false);
		if (!(hit instanceof BlockHitResult blockHit) || blockHit.getType() != HitResult.Type.BLOCK) {
			return;
		}

		BlockState targetState = client.world.getBlockState(blockHit.getBlockPos());
		if (targetState.isAir() || targetState.getBlock() instanceof FluidBlock) {
			return;
		}
		if (!player.isSneaking() && hasUseAction(targetState.getBlock())) {
			return;
		}

		// With an empty hand, use a carpet stack only to work out where a carpet would go.
		ItemStack contextStack = holdingCarpet ? held : new ItemStack(Items.WHITE_CARPET);
		ItemPlacementContext context = new ItemPlacementContext(player, Hand.MAIN_HAND, contextStack, blockHit);
		BlockPos placePos = context.getBlockPos();
		if (!context.canPlace()) {
			return;
		}

		if (client.world.getBlockState(placePos).getBlock() instanceof CarpetBlock) {
			return;
		}
		if (client.world.getBlockState(placePos.down()).getBlock() instanceof CarpetBlock) {
			return;
		}

		Block needed = schematic.getBlockState(placePos).getBlock();
		if (!(needed instanceof CarpetBlock)) {
			return;
		}
		if (isRecentlyPlaced(placePos)) {
			return;
		}
		if (!needed.getDefaultState().canPlaceAt(client.world, placePos)) {
			return;
		}

		Item heldItem = held.getItem();
		boolean heldIsNeeded = heldItem instanceof BlockItem heldBlockItem && heldBlockItem.getBlock() == needed;
		if (!heldIsNeeded) {
			boolean mainInventorySwap = !player.isCreative()
					&& !hotbarHas(player, needed.asItem())
					&& mainInventoryHas(player, needed.asItem());
			if (mainInventorySwap) {
				lastMainSwapNanos = System.nanoTime();
			}

			if (!swapTo(needed.asItem(), placePos, schematic, needed)) {
				warnOutOf(player, needed);
				return;
			}

			Item nowHeld = player.getMainHandStack().getItem();
			if (!(nowHeld instanceof BlockItem nowBlockItem && nowBlockItem.getBlock() == needed)) {
				return;
			}
		}

		rememberPlaced(placePos);
		lastPlaceTick = tickCounter;

		ActionResult result;
		handling = true;
		try {
			result = interaction.interactBlock(player, Hand.MAIN_HAND, blockHit);
		} finally {
			handling = false;
		}

		if (result.isAccepted()) {
			player.swingHand(Hand.MAIN_HAND);
		}
	}

	private static ActionResult onUse(PlayerEntity player, World world, Hand hand, BlockHitResult hitResult) {
		if (handling || !world.isClient() || player.isSpectator()) {
			return ActionResult.PASS;
		}

		BlockState state = world.getBlockState(hitResult.getBlockPos());
		if (state.isAir() || state.getBlock() instanceof FluidBlock) {
			return ActionResult.FAIL;
		}

		if (hand != Hand.MAIN_HAND) {
			return ActionResult.PASS;
		}

		ItemStack stack = player.getStackInHand(hand);
		if (!isCarpet(stack)) {
			return ActionResult.PASS;
		}

		BlockPos placePos = new ItemPlacementContext(player, hand, stack, hitResult).getBlockPos();
		if (world.getBlockState(placePos.down()).getBlock() instanceof CarpetBlock) {
			return ActionResult.FAIL;
		}

		World schematic = getSchematicWorld();
		if (schematic == null) {
			return ActionResult.PASS;
		}

		if (!(schematic.getBlockState(placePos).getBlock() instanceof CarpetBlock)) {
			return ActionResult.PASS;
		}
		return ActionResult.FAIL;
	}

	private static boolean hotbarHas(ClientPlayerEntity player, Item item) {
		PlayerInventory inventory = player.getInventory();
		for (int i = 0; i < 9; i++) {
			if (inventory.getStack(i).isOf(item)) {
				return true;
			}
		}
		return false;
	}

	private static boolean mainInventoryHas(ClientPlayerEntity player, Item item) {
		PlayerInventory inventory = player.getInventory();
		for (int i = 9; i < 36; i++) {
			if (inventory.getStack(i).isOf(item)) {
				return true;
			}
		}
		return false;
	}

	private static boolean hasUseAction(Block block) {
		return block instanceof BlockWithEntity
				|| block instanceof ButtonBlock
				|| block instanceof LeverBlock
				|| block instanceof DoorBlock
				|| block instanceof TrapdoorBlock
				|| block instanceof FenceGateBlock;
	}

	private static boolean isRecentlyPlaced(BlockPos pos) {
		while (!placedCache.isEmpty() && placedCache.peekFirst().expiresAtTick() <= tickCounter) {
			placedCache.pollFirst();
		}
		Iterator<Cached> iterator = placedCache.iterator();
		while (iterator.hasNext()) {
			if (iterator.next().pos().equals(pos)) {
				return true;
			}
		}
		return false;
	}

	private static void rememberPlaced(BlockPos pos) {
		placedCache.addLast(new Cached(pos.toImmutable(), tickCounter + POSITION_CACHE_TICKS));
		while (placedCache.size() > POSITION_CACHE_MAX) {
			placedCache.pollFirst();
		}
	}

	private static void warnOutOf(ClientPlayerEntity player, Block block) {
		long now = System.currentTimeMillis();
		if (now - lastMessageMs > 1500L) {
			lastMessageMs = now;
			player.sendMessage(Text.literal("Out of: ").append(block.getName()), true);
		}
	}

	private static boolean swapTo(Item item, BlockPos pos, World schematic, Block needed) {
		ClientPlayerEntity player = MinecraftClient.getInstance().player;
		Item before = player == null ? null : player.getMainHandStack().getItem();

		boolean pulled = pullFromInventory(item);
		if (pulled && player != null && player.getMainHandStack().getItem() != before) {
			lastSwapTick = tickCounter;
		}
		return pulled;
	}

	private static World getSchematicWorld() {
		if (schematicLookupFailed) {
			return null;
		}
		try {
			if (schematicWorldGetter == null) {
				Class<?> handler = Class.forName("fi.dy.masa.litematica.world.SchematicWorldHandler");
				schematicWorldGetter = handler.getMethod("getSchematicWorld");
			}
			Object result = schematicWorldGetter.invoke(null);
			return result instanceof World world ? world : null;
		} catch (ClassNotFoundException | NoSuchMethodException e) {
			schematicLookupFailed = true;
			return null;
		} catch (Throwable t) {
			return null;
		}
	}

	private static boolean isCarpet(ItemStack stack) {
		Item item = stack.getItem();
		return item instanceof BlockItem blockItem && blockItem.getBlock() instanceof CarpetBlock;
	}

	private static int nextSwapTarget(PlayerInventory inventory) {
		for (int i = 1; i <= 9; i++) {
			int slot = (lastTargetSlot + i) % 9;
			ItemStack stack = inventory.getStack(slot);
			if (stack.isEmpty() || isCarpet(stack)) {
				lastTargetSlot = slot;
				return slot;
			}
		}
		return inventory.getSelectedSlot();
	}

	/**
	 * Brings the wanted item into the selected hotbar slot:
	 * 1) already somewhere in the hotbar -> just select that slot,
	 * 2) in the main inventory -> swap it into a hotbar slot,
	 * 3) creative mode -> give it directly.
	 */
	private static boolean pullFromInventory(Item item) {
		MinecraftClient client = MinecraftClient.getInstance();
		ClientPlayerEntity player = client.player;
		ClientPlayerInteractionManager interaction = client.interactionManager;
		if (player == null || interaction == null) {
			return false;
		}

		PlayerInventory inventory = player.getInventory();
		int selected = inventory.getSelectedSlot();

		for (int i = 0; i < 9; i++) {
			if (inventory.getStack(i).isOf(item)) {
				inventory.setSelectedSlot(i);
				return true;
			}
		}

		for (int i = 9; i < 36; i++) {
			if (inventory.getStack(i).isOf(item)) {
				int target = nextSwapTarget(inventory);
				inventory.setSelectedSlot(target);
				interaction.clickSlot(player.playerScreenHandler.syncId, i, target, SlotActionType.SWAP, player);
				return true;
			}
		}

		if (player.isCreative()) {
			interaction.clickCreativeStack(new ItemStack(item), 36 + selected);
			return true;
		}
		return false;
	}
}
