package org.gradle.wrapper;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Minimal stand-in for Gradle's official wrapper: reads gradle/wrapper/gradle-wrapper.properties,
 * downloads the Gradle distribution once (into ~/.gradle/wrapper/dists), then runs it.
 */
public class GradleWrapperMain {

	public static void main(String[] args) throws Exception {
		Path jar = Paths.get(GradleWrapperMain.class.getProtectionDomain().getCodeSource().getLocation().toURI());
		Path projectDir = jar.toAbsolutePath().getParent().getParent().getParent();

		Properties props = new Properties();
		try (InputStream in = Files.newInputStream(projectDir.resolve("gradle/wrapper/gradle-wrapper.properties"))) {
			props.load(in);
		}
		String url = props.getProperty("distributionUrl");
		if (url == null) {
			fail("distributionUrl missing in gradle/wrapper/gradle-wrapper.properties");
		}

		Path userHome = gradleUserHome();
		String zipName = url.substring(url.lastIndexOf('/') + 1);
		String distName = zipName.endsWith(".zip") ? zipName.substring(0, zipName.length() - 4) : zipName;
		String homeDirName = distName.replaceAll("-(bin|all)$", "");
		Path distsRoot = userHome.resolve("wrapper").resolve("dists").resolve(distName);

		Path gradleHome = findExisting(distsRoot, homeDirName);
		if (gradleHome == null) {
			Path target = distsRoot.resolve("schematiccarpet-wrapper");
			Files.createDirectories(target);
			Path zip = target.resolve(zipName + ".part");
			System.out.println("Downloading " + url);
			download(url, zip);
			System.out.println();
			System.out.println("Unpacking " + zipName + " ...");
			unzip(zip, target);
			Files.deleteIfExists(zip);
			Files.write(target.resolve(".ok"), new byte[0]);
			gradleHome = findExisting(distsRoot, homeDirName);
			if (gradleHome == null) {
				fail("Downloaded distribution does not contain " + homeDirName);
			}
		}

		File libDir = gradleHome.resolve("lib").toFile();
		File[] launchers = libDir.listFiles((d, n) -> n.startsWith("gradle-launcher-") && n.endsWith(".jar"));
		if (launchers == null || launchers.length == 0) {
			fail("Could not find gradle-launcher jar in " + libDir);
		}

		String javaHome = System.getProperty("java.home");
		String javaExe = Paths.get(javaHome, "bin", isWindows() ? "java.exe" : "java").toString();

		List<String> cmd = new ArrayList<>();
		cmd.add(javaExe);
		cmd.add("-Xmx64m");
		cmd.add("-Xms64m");
		cmd.add("-Dorg.gradle.appname=gradlew");
		cmd.add("-classpath");
		cmd.add(launchers[0].getAbsolutePath());
		cmd.add("org.gradle.launcher.GradleMain");
		for (String a : args) {
			cmd.add(a);
		}

		Process p = new ProcessBuilder(cmd).directory(new File(System.getProperty("user.dir"))).inheritIO().start();
		System.exit(p.waitFor());
	}

	private static Path gradleUserHome() {
		String env = System.getenv("GRADLE_USER_HOME");
		if (env != null && !env.isEmpty()) {
			return Paths.get(env);
		}
		String prop = System.getProperty("gradle.user.home");
		if (prop != null && !prop.isEmpty()) {
			return Paths.get(prop);
		}
		return Paths.get(System.getProperty("user.home"), ".gradle");
	}

	/** Looks for an already unpacked distribution (also reuses ones made by the official wrapper). */
	private static Path findExisting(Path distsRoot, String homeDirName) {
		File[] children = distsRoot.toFile().listFiles();
		if (children == null) {
			return null;
		}
		for (File child : children) {
			File home = new File(child, homeDirName);
			if (new File(home, "bin/gradle").isFile() && new File(home, "lib").isDirectory()
					&& new File(child, ".ok").exists()) {
				return home.toPath();
			}
			// official wrapper marks completion with <zipname>.ok
			File[] oks = child.listFiles((d, n) -> n.endsWith(".ok"));
			if (oks != null && oks.length > 0 && new File(home, "bin/gradle").isFile()) {
				return home.toPath();
			}
		}
		return null;
	}

	private static void download(String url, Path target) throws Exception {
		URLConnection conn = new URL(url).openConnection();
		conn.setConnectTimeout(30000);
		conn.setReadTimeout(60000);
		long total = conn.getContentLengthLong();
		long done = 0;
		int lastPct = -1;
		try (InputStream in = conn.getInputStream(); OutputStream out = Files.newOutputStream(target)) {
			byte[] buf = new byte[65536];
			int n;
			while ((n = in.read(buf)) > 0) {
				out.write(buf, 0, n);
				done += n;
				if (total > 0) {
					int pct = (int) (done * 100 / total);
					if (pct / 10 != lastPct / 10) {
						System.out.print(pct + "% ");
						lastPct = pct;
					}
				}
			}
		}
	}

	private static void unzip(Path zip, Path targetDir) throws Exception {
		Path root = targetDir.toAbsolutePath().normalize();
		try (ZipInputStream zin = new ZipInputStream(Files.newInputStream(zip))) {
			ZipEntry entry;
			while ((entry = zin.getNextEntry()) != null) {
				Path out = root.resolve(entry.getName()).normalize();
				if (!out.startsWith(root)) {
					throw new RuntimeException("Bad zip entry: " + entry.getName());
				}
				if (entry.isDirectory()) {
					Files.createDirectories(out);
				} else {
					Files.createDirectories(out.getParent());
					Files.copy(zin, out, StandardCopyOption.REPLACE_EXISTING);
					String name = entry.getName().replace('\\', '/');
					if (name.contains("/bin/")) {
						out.toFile().setExecutable(true, false);
					}
				}
			}
		}
	}

	private static boolean isWindows() {
		return System.getProperty("os.name", "").toLowerCase().contains("win");
	}

	private static void fail(String msg) {
		System.err.println("ERROR: " + msg);
		System.exit(1);
	}
}
